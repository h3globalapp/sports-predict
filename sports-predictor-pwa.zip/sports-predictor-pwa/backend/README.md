
# File 3: Backend README
backend_readme = '''# Sports Prediction Backend

High-accuracy ML ensemble API for sports predictions.

## Setup

```bash
# Install dependencies
pip install -r requirements.txt

# Run development server
python app.py

# Production (Render/Heroku)
gunicorn app:app
```

## API Endpoints

### GET /api/health
Health check and model status.

### GET /api/matches
Get today's matches with features.

### POST /api/predict
Make prediction for a match.

**Request Body:**
```json
{
    "recent_wins": 15,
    "points_avg": 450.5,
    "surface": "hard",
    "is_home": 1,
    "h2h_wins": 8,
    "h2h_losses": 2,
    "rest_days": 2,
    "tournament_level": 2,
    "round": 5,
    "rank": 5,
    "career_titles": 12,
    "age": 27,
    "years_pro": 6,
    "current_streak": 2,
    "altitude": 500,
    "is_home_timezone": 1
}
```

**Response:**
```json
{
    "success": true,
    "data": {
        "win_probability": 0.72,
        "confidence": 0.88,
        "prediction": "WIN",
        "features_used": 50
    },
    "timestamp": "2026-04-19T12:00:00"
}
```

## Model Files Required

Place these files in `backend/model/`:
- `scaler.pkl` - Feature scaler (StandardScaler)
- `ensemble.pkl` - Trained ensemble model (VotingClassifier)

See `../high_accuracy_model.py` for training script.
'''

with open(f'{backend_path}/README.md', 'w') as f:
    f.write(backend_readme)

print("✓ backend/README.md created")